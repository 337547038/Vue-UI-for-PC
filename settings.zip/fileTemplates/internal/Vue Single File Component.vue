<!-- Created by 337547038 on ${DATE}. -->
<template>
  <div>#[[$END$]]#</div>
</template>

<script>
export default {
  name: "${COMPONENT_NAME}",
  data () {
   return {}
  },
  props: {},
  components: {},
  methods: {},
  computed: {},
  mounted () {}
}
</script>